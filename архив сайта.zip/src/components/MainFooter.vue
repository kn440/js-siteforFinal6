<template>
    
    <div class="footer">
        <div class="footer__cnt">
            <a href="#" class="footer__cnt__link">
                <img class="footer__cnt__link__img" src="" alt="">
                Логотип
            </a>
        <div class="footer__cnt__link">Страницы</div>
        <div class="footer__cnt__link">Контакты</div>
            </div>    
    </div>
    
  </template>
  
  <script>
  export default {
    name: 'MainFooter',
   
  }
  </script>
  
  <!-- Add "scoped" attribute to limit CSS to this component only 
   -->
  <style scoped lang="scss">
  @import '../assets/filesforstyle/vars';
    .footer{
        @include ParamWHM($widthfooter, $heightfooter, none, none, 250px, none);
        background-color: $colorfooter;
        display:block;
        position: absolute;
        &__cnt{
            @include ParamWHM($widthfootercnt, $heightfootercnt, 370px, none, 60px, none);
            background-color:#FFF;
            position: relative;
            justify-content:space-between;
            display: grid;
            flex-wrap: wrap;
            grid-template-columns: repeat(3, 320px);
            grid-auto-flow: dense;
            &__link {
                &__text {
                    @include ParamText(#222, Jost, 13px, 400, none, center);
                    margin-top: 24px;
                    margin-bottom: 25px;
                }
            }
        }
    }
 
  </style>