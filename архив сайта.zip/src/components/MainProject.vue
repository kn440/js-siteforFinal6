<template>
    <div>
      <h1>About Page</h1>
      <a href="#" @click.prevent="goToHome">Go to Home Page</a>
      <div class="tags">
        <button v-for="tag in uniqueTags" :key="tag" @click="selectTag(tag)" :class="{ active: selectedTag === tag }">
          {{ tag }}
        </button>
      </div>
      <div class="items">
        <div v-for="item in filteredItems" :key="item.id" class="item">
          <img :src="item.image" alt="Item image" />
          <p>{{ item.text }}</p>
          <span>{{ item.tag }}</span>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  
  
  export default {
    name: 'MainProject',
    data() {
    return {
      items: [
        { id: 1, image: './img/s41/Image1.png', text: 'Item 1', tag: 'Nature' },
        { id: 2, image: './img/s41/Image2.png', text: 'Item 2', tag: 'Technology' },
        { id: 3, image: './img/s41/Image3.png', text: 'Item 3', tag: 'Nature' },
        { id: 4, image: './img/s41/Image4.png', text: 'Item 4', tag: 'Architecture' },
       
      ],
      selectedTag: 'All'
    };
  },
  computed: {
    uniqueTags() {
      const tags = this.items.map(item => item.tag);
      return ['All', ...new Set(tags)];
    },
    filteredItems() {
      if (this.selectedTag === 'All') {
        return this.items;
      }
      return this.items.filter(item => item.tag === this.selectedTag);
    }
  },
    methods: {
      goToHome() {
        this.$emit('navigate', 'MainPage');
      },
      selectTag(tag) {
      this.selectedTag = tag;
    }
    }
  };
  </script>
 <style scoped>
 .tags {
   margin-bottom: 20px;
 }
 .tags button {
   margin-right: 10px;
   padding: 5px 10px;
   cursor: pointer;
 }
 .tags button.active {
   font-weight: bold;
 }
 .items {
   display: flex;
   flex-wrap: wrap;
 }
 .item {
   margin: 10px;
   border: 1px solid #ddd;
   padding: 10px;
   text-align: center;
 }
 .item img {
   max-width: 100%;
 }
 </style>